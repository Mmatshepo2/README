﻿namespace Icep1
{
    partial class Contents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.subjectsContentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mMX30ATToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.studyGuideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.assignmentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revisionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mMX30BTToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.studyGuideToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.assignmentsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.revisionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mMZ30ATToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.studyGuideToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.assignmentsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.revisionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mMZ30BTToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.studyGuideToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.assignmentsToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.revisionToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.subjectsContentsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(213, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 199);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(138, 199);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // subjectsContentsToolStripMenuItem
            // 
            this.subjectsContentsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mMX30ATToolStripMenuItem1,
            this.mMX30BTToolStripMenuItem1,
            this.mMZ30ATToolStripMenuItem1,
            this.mMZ30BTToolStripMenuItem1});
            this.subjectsContentsToolStripMenuItem.Name = "subjectsContentsToolStripMenuItem";
            this.subjectsContentsToolStripMenuItem.Size = new System.Drawing.Size(114, 20);
            this.subjectsContentsToolStripMenuItem.Text = "Subjects Contents";
            // 
            // mMX30ATToolStripMenuItem1
            // 
            this.mMX30ATToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studyGuideToolStripMenuItem});
            this.mMX30ATToolStripMenuItem1.Name = "mMX30ATToolStripMenuItem1";
            this.mMX30ATToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.mMX30ATToolStripMenuItem1.Text = "MMX30AT";
            // 
            // studyGuideToolStripMenuItem
            // 
            this.studyGuideToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.assignmentsToolStripMenuItem});
            this.studyGuideToolStripMenuItem.Name = "studyGuideToolStripMenuItem";
            this.studyGuideToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.studyGuideToolStripMenuItem.Text = "Study Guide";
            // 
            // assignmentsToolStripMenuItem
            // 
            this.assignmentsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revisionToolStripMenuItem});
            this.assignmentsToolStripMenuItem.Name = "assignmentsToolStripMenuItem";
            this.assignmentsToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.assignmentsToolStripMenuItem.Text = "Assignments";
            // 
            // revisionToolStripMenuItem
            // 
            this.revisionToolStripMenuItem.Name = "revisionToolStripMenuItem";
            this.revisionToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.revisionToolStripMenuItem.Text = "Revision";
            // 
            // mMX30BTToolStripMenuItem1
            // 
            this.mMX30BTToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studyGuideToolStripMenuItem1});
            this.mMX30BTToolStripMenuItem1.Name = "mMX30BTToolStripMenuItem1";
            this.mMX30BTToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.mMX30BTToolStripMenuItem1.Text = "MMX30BT";
            // 
            // studyGuideToolStripMenuItem1
            // 
            this.studyGuideToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.assignmentsToolStripMenuItem1});
            this.studyGuideToolStripMenuItem1.Name = "studyGuideToolStripMenuItem1";
            this.studyGuideToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.studyGuideToolStripMenuItem1.Text = "Study Guide";
            // 
            // assignmentsToolStripMenuItem1
            // 
            this.assignmentsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revisionToolStripMenuItem1});
            this.assignmentsToolStripMenuItem1.Name = "assignmentsToolStripMenuItem1";
            this.assignmentsToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.assignmentsToolStripMenuItem1.Text = "Assignments";
            this.assignmentsToolStripMenuItem1.Click += new System.EventHandler(this.assignmentsToolStripMenuItem1_Click);
            // 
            // revisionToolStripMenuItem1
            // 
            this.revisionToolStripMenuItem1.Name = "revisionToolStripMenuItem1";
            this.revisionToolStripMenuItem1.Size = new System.Drawing.Size(118, 22);
            this.revisionToolStripMenuItem1.Text = "Revision";
            // 
            // mMZ30ATToolStripMenuItem1
            // 
            this.mMZ30ATToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studyGuideToolStripMenuItem2});
            this.mMZ30ATToolStripMenuItem1.Name = "mMZ30ATToolStripMenuItem1";
            this.mMZ30ATToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.mMZ30ATToolStripMenuItem1.Text = "MMZ30AT";
            // 
            // studyGuideToolStripMenuItem2
            // 
            this.studyGuideToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.assignmentsToolStripMenuItem2});
            this.studyGuideToolStripMenuItem2.Name = "studyGuideToolStripMenuItem2";
            this.studyGuideToolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.studyGuideToolStripMenuItem2.Text = "Study Guide";
            // 
            // assignmentsToolStripMenuItem2
            // 
            this.assignmentsToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revisionsToolStripMenuItem});
            this.assignmentsToolStripMenuItem2.Name = "assignmentsToolStripMenuItem2";
            this.assignmentsToolStripMenuItem2.Size = new System.Drawing.Size(142, 22);
            this.assignmentsToolStripMenuItem2.Text = "Assignments";
            // 
            // revisionsToolStripMenuItem
            // 
            this.revisionsToolStripMenuItem.Name = "revisionsToolStripMenuItem";
            this.revisionsToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.revisionsToolStripMenuItem.Text = "Revision";
            // 
            // mMZ30BTToolStripMenuItem1
            // 
            this.mMZ30BTToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studyGuideToolStripMenuItem3});
            this.mMZ30BTToolStripMenuItem1.Name = "mMZ30BTToolStripMenuItem1";
            this.mMZ30BTToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.mMZ30BTToolStripMenuItem1.Text = "MMZ30BT";
            // 
            // studyGuideToolStripMenuItem3
            // 
            this.studyGuideToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.assignmentsToolStripMenuItem3});
            this.studyGuideToolStripMenuItem3.Name = "studyGuideToolStripMenuItem3";
            this.studyGuideToolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.studyGuideToolStripMenuItem3.Text = "Study Guide";
            // 
            // assignmentsToolStripMenuItem3
            // 
            this.assignmentsToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.revisionToolStripMenuItem2});
            this.assignmentsToolStripMenuItem3.Name = "assignmentsToolStripMenuItem3";
            this.assignmentsToolStripMenuItem3.Size = new System.Drawing.Size(142, 22);
            this.assignmentsToolStripMenuItem3.Text = "Assignments";
            // 
            // revisionToolStripMenuItem2
            // 
            this.revisionToolStripMenuItem2.Name = "revisionToolStripMenuItem2";
            this.revisionToolStripMenuItem2.Size = new System.Drawing.Size(118, 22);
            this.revisionToolStripMenuItem2.Text = "Revision";
            // 
            // Contents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(213, 235);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Contents";
            this.Text = "Contents";
            this.Load += new System.EventHandler(this.Contents_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem subjectsContentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mMX30ATToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studyGuideToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem assignmentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revisionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mMX30BTToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studyGuideToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem assignmentsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem revisionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mMZ30ATToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studyGuideToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem assignmentsToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem revisionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mMZ30BTToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studyGuideToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem assignmentsToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem revisionToolStripMenuItem2;
    }
}