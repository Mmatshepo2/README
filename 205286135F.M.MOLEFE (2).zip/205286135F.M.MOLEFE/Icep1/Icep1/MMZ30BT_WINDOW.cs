﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Icep1
{
    public partial class MMZ30BT_WINDOW : Form
    {
        public MMZ30BT_WINDOW()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Subjects ss = new Subjects();
            ss.Show();
        }
    }
}
