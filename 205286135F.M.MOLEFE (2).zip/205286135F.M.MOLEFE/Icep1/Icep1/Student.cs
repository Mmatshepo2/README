﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Icep1
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }



        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Student_Load(object sender, EventArgs e)
        {
            //Load data into the modelDataSet Student Table



        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                String str = "C:\\Users\\Mmatshepo\\AppData\\Local\\Microsoft\\Microsoft SQL Server Local DB\\Instances\\MSSQLLocalDB";

                String query = "select * from data";
                SqlConnection con = new SqlConnection(str);
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                DataSet ds = new DataSet();
                MessageBox.Show("connect with sql server");
                con.Close();




            }

            catch (Exception es)
            {
                MessageBox.Show(es.Message);
            }
            this.Hide();
            Form2 ss = new Form2();
            ss.Show();


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }
    }
}
