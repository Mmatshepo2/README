﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Icep1
{
    public partial class Subjects : Form
    {
        public Subjects()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 ss = new Form2();
            ss.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Subjects_Load(object sender, EventArgs e)
        {

        }

        private void mMX30ATToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            MMX30AT_WINDOW ss = new MMX30AT_WINDOW();
            ss.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            MMZ30BT_WINDOW ss = new MMZ30BT_WINDOW();
            ss.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MMX30AT_WINDOW ss = new MMX30BT_WINDOW();
            ss.Show();
        }

        private class MMX30BT_WINDOW : MMX30AT_WINDOW
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            MMZ30AT_WINDOW ss = new MMZ30AT_WINDOW();
            ss.Show();
        }
    }
}
