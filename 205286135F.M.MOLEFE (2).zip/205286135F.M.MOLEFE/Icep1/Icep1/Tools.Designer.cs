﻿namespace Icep1
{
    partial class Tools
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.personalInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restPasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.announcementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importantInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.semesterSubjectsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calendarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mMX30AT60ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mMX30BT50ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mMZ30ATNotAvailableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mMZ30BT45ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.titleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.priorityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dueDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taskStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.classInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.notYetSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(252, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.personalInformationToolStripMenuItem,
            this.announcementToolStripMenuItem,
            this.calendarToolStripMenuItem,
            this.marksToolStripMenuItem,
            this.taskToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // personalInformationToolStripMenuItem
            // 
            this.personalInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.changePasswordToolStripMenuItem,
            this.restPasswordToolStripMenuItem});
            this.personalInformationToolStripMenuItem.Name = "personalInformationToolStripMenuItem";
            this.personalInformationToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.personalInformationToolStripMenuItem.Text = "Personal Information";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            // 
            // restPasswordToolStripMenuItem
            // 
            this.restPasswordToolStripMenuItem.Name = "restPasswordToolStripMenuItem";
            this.restPasswordToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.restPasswordToolStripMenuItem.Text = "Personalise Settings";
            // 
            // announcementToolStripMenuItem
            // 
            this.announcementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importantInformationToolStripMenuItem,
            this.semesterSubjectsToolStripMenuItem});
            this.announcementToolStripMenuItem.Name = "announcementToolStripMenuItem";
            this.announcementToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.announcementToolStripMenuItem.Text = "Announcement";
            // 
            // importantInformationToolStripMenuItem
            // 
            this.importantInformationToolStripMenuItem.Name = "importantInformationToolStripMenuItem";
            this.importantInformationToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.importantInformationToolStripMenuItem.Text = "Important Information";
            // 
            // semesterSubjectsToolStripMenuItem
            // 
            this.semesterSubjectsToolStripMenuItem.Name = "semesterSubjectsToolStripMenuItem";
            this.semesterSubjectsToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.semesterSubjectsToolStripMenuItem.Text = "Semester Subjects";
            // 
            // calendarToolStripMenuItem
            // 
            this.calendarToolStripMenuItem.Name = "calendarToolStripMenuItem";
            this.calendarToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.calendarToolStripMenuItem.Text = "Calendar";
            // 
            // marksToolStripMenuItem
            // 
            this.marksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mMX30AT60ToolStripMenuItem,
            this.mMX30BT50ToolStripMenuItem,
            this.mMZ30ATNotAvailableToolStripMenuItem,
            this.mMZ30BT45ToolStripMenuItem});
            this.marksToolStripMenuItem.Name = "marksToolStripMenuItem";
            this.marksToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.marksToolStripMenuItem.Text = "Marks";
            // 
            // mMX30AT60ToolStripMenuItem
            // 
            this.mMX30AT60ToolStripMenuItem.Name = "mMX30AT60ToolStripMenuItem";
            this.mMX30AT60ToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.mMX30AT60ToolStripMenuItem.Text = "MMX30AT:   60%";
            // 
            // mMX30BT50ToolStripMenuItem
            // 
            this.mMX30BT50ToolStripMenuItem.Name = "mMX30BT50ToolStripMenuItem";
            this.mMX30BT50ToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.mMX30BT50ToolStripMenuItem.Text = "MMX30BT:   50%";
            // 
            // mMZ30ATNotAvailableToolStripMenuItem
            // 
            this.mMZ30ATNotAvailableToolStripMenuItem.Name = "mMZ30ATNotAvailableToolStripMenuItem";
            this.mMZ30ATNotAvailableToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.mMZ30ATNotAvailableToolStripMenuItem.Text = "MMZ30AT :  Not Available";
            // 
            // mMZ30BT45ToolStripMenuItem
            // 
            this.mMZ30BT45ToolStripMenuItem.Name = "mMZ30BT45ToolStripMenuItem";
            this.mMZ30BT45ToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.mMZ30BT45ToolStripMenuItem.Text = "MMZ30BT:   45%";
            // 
            // taskToolStripMenuItem
            // 
            this.taskToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.titleToolStripMenuItem,
            this.classInformationToolStripMenuItem});
            this.taskToolStripMenuItem.Name = "taskToolStripMenuItem";
            this.taskToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.taskToolStripMenuItem.Text = "Tasks";
            this.taskToolStripMenuItem.Click += new System.EventHandler(this.taskToolStripMenuItem_Click);
            // 
            // titleToolStripMenuItem
            // 
            this.titleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.priorityToolStripMenuItem});
            this.titleToolStripMenuItem.Name = "titleToolStripMenuItem";
            this.titleToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.titleToolStripMenuItem.Text = "Title";
            this.titleToolStripMenuItem.Click += new System.EventHandler(this.titleToolStripMenuItem_Click);
            // 
            // priorityToolStripMenuItem
            // 
            this.priorityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dueDateToolStripMenuItem,
            this.toolStripMenuItem2});
            this.priorityToolStripMenuItem.Name = "priorityToolStripMenuItem";
            this.priorityToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.priorityToolStripMenuItem.Text = "Priority";
            // 
            // dueDateToolStripMenuItem
            // 
            this.dueDateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.taskStatusToolStripMenuItem,
            this.notYetSToolStripMenuItem});
            this.dueDateToolStripMenuItem.Name = "dueDateToolStripMenuItem";
            this.dueDateToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.dueDateToolStripMenuItem.Text = "Due Date";
            // 
            // taskStatusToolStripMenuItem
            // 
            this.taskStatusToolStripMenuItem.Name = "taskStatusToolStripMenuItem";
            this.taskStatusToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.taskStatusToolStripMenuItem.Text = "Task Status";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 220);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(165, 220);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // classInformationToolStripMenuItem
            // 
            this.classInformationToolStripMenuItem.Name = "classInformationToolStripMenuItem";
            this.classInformationToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.classInformationToolStripMenuItem.Text = "Class Information";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem2.Text = "20/05/2021";
            // 
            // notYetSToolStripMenuItem
            // 
            this.notYetSToolStripMenuItem.Name = "notYetSToolStripMenuItem";
            this.notYetSToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.notYetSToolStripMenuItem.Text = "not yet started";
            // 
            // Tools
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(252, 270);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Tools";
            this.Text = "Tools";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem personalInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem announcementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calendarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marksToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restPasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importantInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem semesterSubjectsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mMX30AT60ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mMX30BT50ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mMZ30ATNotAvailableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mMZ30BT45ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem titleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem priorityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dueDateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taskStatusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notYetSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}