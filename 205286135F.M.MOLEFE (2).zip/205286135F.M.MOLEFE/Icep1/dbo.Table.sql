﻿CREATE TABLE [dbo].[Students]
(
 	[FullName] NVARCHAR (100) NULL,
	[Email] VARCHAR (150) NULL,
	[Address] NVARCHAR (500) NULL,
	[Phone] VARCHAR (25) NULL,
	[Gender] BIT NULL,
	PRIMARY KEY CLUSTERED ([Id] ASC)

)
